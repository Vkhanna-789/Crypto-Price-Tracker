import React from 'react';
import { FaCoins } from 'react-icons/fa';
import { Link } from 'react-router-dom';
import './Navbar.css';

const Navbar = ({ searchQuery, setSearchQuery }) => {
  const handleInputChange = (e) => {
    setSearchQuery(e.target.value);
  };

  return (
    <div className='navbar'>
      <Link to='/'>
        <div className='logo'>
          <FaCoins className='icon' />
          <h1>Coin<span className='purple'>Sparkle</span></h1>
        </div>
      </Link>
      <input
        type="text"
        placeholder="Search for a coin"
        value={searchQuery}
        onChange={handleInputChange}
        className='search-input'
      />
    </div>
  );
};

export default Navbar;
